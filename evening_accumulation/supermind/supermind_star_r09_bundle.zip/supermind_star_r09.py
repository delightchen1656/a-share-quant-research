"""SuperMind minute-frequency simulation strategy for STAR r09.

Upload this file and star_r09_model.json to the same SuperMind project folder.
Set strategy frequency to 1 minute. This is simulation code, not investment advice.
"""
from mindgo_api import *
import base64
import json
import math
import os
import zlib

import numpy as np
import pandas as pd


_EMBEDDED_MODEL_B64 = ""


def _load_model():
    if _EMBEDDED_MODEL_B64:
        raw = zlib.decompress(base64.b64decode(_EMBEDDED_MODEL_B64.encode("ascii")))
        return json.loads(raw.decode("utf-8"))
    candidates = ["star_r09_model.json"]
    if "__file__" in globals():
        candidates.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "star_r09_model.json"))
    for path in candidates:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    raise IOError("star_r09_model.json not found; upload it beside the strategy file")


def _tree_probability(model, values):
    raw = float(model["baseline"])
    for tree in model["trees"]:
        i = 0
        while not tree[i]["leaf"]:
            node = tree[i]
            x = values[node["f"]]
            go_left = node["m"] if np.isnan(x) else x <= node["t"]
            i = node["l"] if go_left else node["r"]
        raw += tree[i]["v"]
    if raw >= 0:
        z = math.exp(-raw)
        return 1.0 / (1.0 + z)
    z = math.exp(raw)
    return z / (1.0 + z)


def _last_features(df):
    if df is None or len(df) < 120:
        return None
    x = df.sort_index().copy()
    c, v = x["close"], x["volume"]
    r = c.pct_change(fill_method=None)
    vchg = v.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    out = {}
    out["ret5"] = c.pct_change(5, fill_method=None).iloc[-1]
    out["ret20"] = c.pct_change(20, fill_method=None).iloc[-1]
    out["ret60"] = c.pct_change(60, fill_method=None).iloc[-1]
    out["range20"] = x.high.rolling(20).max().iloc[-1] / x.low.rolling(20).min().iloc[-1] - 1
    out["range60"] = x.high.rolling(60).max().iloc[-1] / x.low.rolling(60).min().iloc[-1] - 1
    out["dd20"] = c.iloc[-1] / c.rolling(20).max().iloc[-1] - 1
    out["vol20"] = r.rolling(20).std().iloc[-1]
    out["vol60"] = r.rolling(60).std().iloc[-1]
    out["volume_ratio"] = v.rolling(5).mean().iloc[-1] / v.rolling(20).mean().iloc[-1]
    out["volume_cv"] = v.rolling(20).std().iloc[-1] / v.rolling(20).mean().iloc[-1]
    out["up_volume_share"] = v.where(r > 0, 0).rolling(20).sum().iloc[-1] / v.rolling(20).sum().iloc[-1]
    out["pv_corr"] = r.rolling(20).corr(vchg).iloc[-1]
    low60, high60 = c.rolling(60).min().iloc[-1], c.rolling(60).max().iloc[-1]
    out["close_pos60"] = (c.iloc[-1] - low60) / (high60 - low60) if high60 != low60 else np.nan
    out["turn20"] = x.turnover_rate.rolling(20).mean().iloc[-1]
    out["amount20"] = np.log1p(x.turnover.rolling(20).mean().iloc[-1])
    out["breakout_gap"] = c.iloc[-1] / c.shift(1).rolling(60).max().iloc[-1] - 1
    out["rise_from_low60"] = c.iloc[-1] / low60 - 1
    out["volume_spike"] = v.iloc[-1] / v.rolling(20).mean().iloc[-1]
    # The same hard anti-chasing filters used by r09.
    if (out["ret5"] > 0.12 or out["ret20"] > 0.20 or out["rise_from_low60"] > 0.30
            or out["volume_spike"] > 5 or x.high.iloc[-1] == x.low.iloc[-1]
            or x.quote_rate.iloc[-1] >= 19.5 or x.turnover.rolling(20).mean().iloc[-1] < 50000000
            or bool(x.is_st.iloc[-1])):
        return None
    values = [float(out[name]) for name in g.model["features"]]
    if not np.all(np.isfinite(values)):
        return None
    return values


def init(context):
    g.model = _load_model()
    g.pending = []
    g.position_state = {}
    g.order_intent = {}
    g.order_locks = {}
    g.buy_done_date = None
    set_benchmark("000688.SH")
    # PriceSlippage is the full spread; 0.002 means about 0.1% on each side.
    set_slippage(PriceSlippage(0.002))
    set_commission(PerShare(type="stock", cost=0.0003, min_trade_cost=5.0))
    set_volume_limit(daily=0.25, minute=0.5)
    log.info("STAR r09 initialized; use 1-minute frequency")


def before_trading(context):
    today = get_datetime().date()
    g.order_locks = {}
    # Frozen 2026-07-31 universe, identical to the local r09 experiment.
    symbols = g.model["universe"]
    fields = ["open", "high", "low", "close", "volume", "turnover", "turnover_rate", "quote_rate", "is_st"]
    scored = []
    # Chunking avoids a single oversized platform query.
    for begin in range(0, len(symbols), 100):
        batch = symbols[begin:begin + 100]
        data = history(batch, fields, 121, "1d", True, "pre", True, False)
        for symbol in batch:
            values = _last_features(data.get(symbol) if isinstance(data, dict) else None)
            if values is None:
                continue
            probability = _tree_probability(g.model, values)
            if probability >= g.model["threshold"]:
                scored.append((symbol, probability))
    scored.sort(key=lambda item: item[1], reverse=True)
    g.pending = scored[:g.model["top_per_day"]]
    g.buy_done_date = None
    log.info("STAR candidates: %s" % str(g.pending))


def _submit(symbol, target_amount, action):
    if symbol in g.order_locks:
        return
    order_id = order_target(symbol, int(target_amount))
    if order_id is not None:
        g.order_locks[symbol] = order_id
        g.order_intent[order_id] = {"symbol": symbol, "action": action}


def handle_bar(context, bar_dict):
    now = get_datetime()
    positions = context.portfolio.positions
    # Execute yesterday-close candidates once after today's open.
    if g.buy_done_date != now.date():
        slots = max(0, g.model["max_positions"] - len(positions))
        for symbol, probability in g.pending:
            if slots <= 0:
                break
            if symbol in positions or symbol in g.order_locks:
                continue
            order_id = order_target_percent(symbol, 0.10)
            if order_id is not None:
                g.order_locks[symbol] = order_id
                g.order_intent[order_id] = {"symbol": symbol, "action": "BUY", "probability": probability}
                slots -= 1
        g.buy_done_date = now.date()
    # Minute-level risk management.
    for symbol in list(positions.keys()):
        pos = positions[symbol]
        if symbol not in g.position_state:
            g.position_state[symbol] = {"entry": float(pos.cost_basis), "half": False}
        state = g.position_state[symbol]
        price = float(pos.last_price)
        if price <= state["entry"] * 0.94:
            _submit(symbol, 0, "STOP")
        elif price >= state["entry"] * 1.30:
            _submit(symbol, 0, "TP30")
        elif price >= state["entry"] * 1.20 and not state["half"]:
            _submit(symbol, max(0, int(pos.amount / 2)), "TP20")
        elif int(pos.position_days) >= 60:
            _submit(symbol, 0, "TIME")


def on_order(context, odr):
    intent = g.order_intent.get(odr.order_id)
    if intent is None:
        return
    status = str(odr.status)
    symbol, action = intent["symbol"], intent["action"]
    if "FILLED" in status:
        if action == "TP20" and symbol in g.position_state:
            g.position_state[symbol]["half"] = True
        elif action in ("STOP", "TP30", "TIME"):
            g.position_state.pop(symbol, None)
        g.order_locks.pop(symbol, None)
        g.order_intent.pop(odr.order_id, None)
        log.info("filled %s %s" % (action, symbol))
    elif "REJECTED" in status or "CANCELLED" in status:
        g.order_locks.pop(symbol, None)
        g.order_intent.pop(odr.order_id, None)
        log.warn("order failed %s %s" % (action, symbol))
